Place into `~/.local/share/plasma/plasmoids/`  
Configure to your needs from the plasmoid menu "Configure Chili Clock"
